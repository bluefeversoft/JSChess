$(function() {
	init();
	console.log("Main Init Called");

});

function init() {
	console.log("init() called");
}