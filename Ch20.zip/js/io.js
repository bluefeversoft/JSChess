function PrSq(sq) {

	return (FileChar[FilesBrd[sq]] + RankChar[RanksBrd[sq]]);

}